#include "FreeRTOS.h"
#include "task.h"
#include "led.h"
#include "timer.h"
#include "stm32f4xx.h"
#include "sys.h"

void Task1_led0()
{
	while(1)
	{
		LED0 = !LED0;
		vTaskDelay(1500);	 //delay 1500ms
	}
}

void Task2_led1()
{
	while(1)
	{
		LED1 = !LED1;
		vTaskDelay(500);	 //delay 500ms
	}
}

 int main(void)
 {	
	 
	 NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
	 delay_init(168);
	 LED_Init();
	 xTaskCreate(Task1_led0,"TASK1_led0",40,NULL,1,NULL);
	 xTaskCreate(Task2_led1,"TASK2_led1",40,NULL,2,NULL);
	 vTaskStartScheduler();
 }
