/*
功能：初始化函数，完成MIO引脚功能设置、数据格式、波特率设置
数据格式为：8位数据位，1位停止位，无校验
波特率为：115200b/s(假设UART端口时钟频率为50MHz)
*/
#include <stdio.h>

#define MIO_PIN_50      (*(volatile unsigned long *)0xF80007C8)
#define DIRM_0          (*(volatile unsigned long *)0xE000A204)
#define DIRM_1          (*(volatile unsigned long *)0xE000A244)
#define OEN_0           (*(volatile unsigned long *)0xE000A208)
#define DATA_0          (*(volatile unsigned long *)0xE000A040)
#define DATA_1_RO       (*(volatile unsigned long *)0xE000A064)

#define rMIO_PIN_48                     (*(volatile unsigned long *)0xF80007C0)
#define rMIO_PIN_49                     (*(volatile unsigned long *)0xF80007C4)
#define rUART_CLK_CTRL              (*(volatile unsigned long *)0xF8000154)
#define rControl_reg0               (*(volatile unsigned long *)0xE0001000)
#define rMode_reg0                  (*(volatile unsigned long *)0xE0001004)
#define rBaud_rate_gen_reg0         (*(volatile unsigned long *)0xE0001018)
#define rBaud_rate_divider_reg0     (*(volatile unsigned long *)0xE0001034)
#define rTx_Rx_FIFO0                    (*(volatile unsigned long *)0xE0001030)
#define rChannel_sts_reg0               (*(volatile unsigned long *)0xE000102C)

void RS232_Init(void){
    rMIO_PIN_48 = 0x000026E0;           //设置MIO[48]引脚功能，引脚电压3.3v
    rMIO_PIN_49 = 0x000026E0;           //设置MIO[49]引脚功能，引脚电压3.3v
    rUART_CLK_CTRL = 0x00001402;        //设置UART_CLK_CTRL 寄存器
    rControl_reg0 = 0x00000017;     //设置Control_reg0 寄存器
    rMode_reg0  = 0x00000020;       //数据格式：8位数据位、1位停止位、无校验等
    //设置波特率115200b/s 根据表4-3查的CD,BDIV参数
    rBaud_rate_gen_reg0 = 62;
    rBaud_rate_divider_reg0 = 6;
}

/* 注：未用到的寄存器位应保持其原有值不变 */

/*****************************************************************
功能：发送函数，完成异步串行通信的发送，一次只发送一个字符
******************************************************************/
void send_Char(unsigned char data)
{
    // 先判断发送FIFO是非满，若满则循环查询，直到发送FIFO不满
    while ((rChannel_sts_reg0 & 0x10) == 0x10);
    // 发送一字节数据
    rTx_Rx_FIFO0 = data;
}

int status;
void loop(){
    status = DATA_1_RO;
    if((status&0x00040000)!=0){
        send_Char('9');
        send_Char('1');
        send_Char('9');
        send_Char('1');
        send_Char('0');
        send_Char('7');
        send_Char('8');
        send_Char('2');
        send_Char('0');
        send_Char('4');
    }else{
        status = DATA_1_RO;
    }
}
int main(){
    RS232_Init();
    while(1){
        loop();
    }
    return 0;
}
